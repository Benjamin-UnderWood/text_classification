Deep Learning with Theano

For chapter 01, 07, 08, 09, 10 and 12 use the code from the chapter. There are no code files for chapter 07 and 08.

Happy code testing!!!